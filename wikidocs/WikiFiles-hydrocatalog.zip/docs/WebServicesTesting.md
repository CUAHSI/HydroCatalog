Operational Services Testing Document:

In Progress:
* Services Uptime Tester written In java.

Undergoing Revision:
* [Web Service WSDL Tester](url_http___hydro13.sdsc.edu_WSDL_TestWSDL-WebMethod.aspx)
	* Code In repository at: svn/serviicestesting/donet/trunk
