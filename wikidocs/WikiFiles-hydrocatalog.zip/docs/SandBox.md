Projects that are in the sandbox:
* OData Example to expose ODM databases
* [HIS Central Catalog Services for the Web using GI-Cat](HIS-Central-Catalog-Services-for-the-Web-using-GI-Cat)