
* Original documentation

# Rest Enabled Version
* [GenericOdWs Notes on Rest](GenericOdWs-Notes-on-Rest)