
GeMet has an API. Examples on how to export tables, and RDF.
* [ http://www.eionet.europa.eu/gemet/rdf]( http://www.eionet.europa.eu/gemet/rdf)
