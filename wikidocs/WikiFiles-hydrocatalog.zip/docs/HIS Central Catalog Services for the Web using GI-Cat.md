
Goals:
* expose Networks table via a CSW interface
* Provide example ISO Metadata for

Use: 
* [GI-Cat](http://zeus.pin.unifi.it/cgi-bin/twiki/view/GIcat)

Tasks:
* IsoMetadata for the Networks Table
	* export to directory, expose as GI-Cat file service
* Create ACCESSOR [GI-Cat develop,ment](http://zeus.pin.unifi.it/cgi-bin/twiki/view/GIcat/Development)
	* [details in the [ gi-cat documentation ]( gi-cat documentation )(-http___zeus.pin.unifi.it_cgi-bin_twiki_view_GIcat_Development)
