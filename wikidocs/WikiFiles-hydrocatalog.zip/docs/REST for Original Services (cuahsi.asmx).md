Not all endpoints named cuahsi_1_1.asmx and cuahsi_1_0.asmx allow for rest.
This functionality was depreciated because it broke the ability of java (and other languages) to utilize the services.

GetSites
* [http://water.sdsc.edu/lbrsdsc/cuahsi_1_1.asmx/GetSitesObject?site=&authToken=](http://water.sdsc.edu/lbrsdsc/cuahsi_1_1.asmx/GetSitesObject?site=&authToken=)
* [http://water.sdsc.edu/lbrsdsc/cuahsi_1_0.asmx/GetSitesXml?site=&authToken=](http://water.sdsc.edu/lbrsdsc/cuahsi_1_0.asmx/GetSitesXml?site=&authToken=)

GetSiteInfo
* [ http://water.sdsc.edu/lbrsdsc/cuahsi_1_1.asmx/GetSiteInfoObject?Site=LBRSDSC:USU-LBR-SFLower&authToken=]( http://water.sdsc.edu/lbrsdsc/cuahsi_1_1.asmx/GetSiteInfoObject?Site=LBRSDSC:USU-LBR-SFLower&authToken=)
* [ http://water.sdsc.edu/lbrsdsc/cuahsi_1_0.asmx/GetSiteInfoObject?Site=LBRSDSC:USU-LBR-SFLower&authToken=]( http://water.sdsc.edu/lbrsdsc/cuahsi_1_0.asmx/GetSiteInfoObject?Site=LBRSDSC:USU-LBR-SFLower&authToken=)

GetSiteInfoMulitple
* [ http://water.sdsc.edu/lbrsdsc/cuahsi_1_1.asmx/GetSiteInfoMultpleObject?Site=LBRSDSC:USU-LBR-SFLower&site=LBRSDSC:USU-LBR-ExpFarm&authToken=]( http://water.sdsc.edu/lbrsdsc/cuahsi_1_1.asmx/GetSiteInfoMultpleObject?Site=LBRSDSC:USU-LBR-SFLower&site=LBRSDSC:USU-LBR-ExpFarm&authToken=)


GetVariable
* [ http://water.sdsc.edu/lbrsdsc/cuahsi_1_1.asmx/GetVariableInfoObject?variable=&authToken=]( http://water.sdsc.edu/lbrsdsc/cuahsi_1_1.asmx/GetVariableInfoObject?variable=&authToken=)
* [ http://water.sdsc.edu/lbrsdsc/cuahsi_1_0.asmx/GetVariableInfoObject?variable=&authToken=]( http://water.sdsc.edu/lbrsdsc/cuahsi_1_0.asmx/GetVariableInfoObject?variable=&authToken=)

GetValues:
* [ http://water.sdsc.edu/lbrsdsc/cuahsi_1_1.asmx/GetValuesObject?variable=LRBSDSC:USU4&location=LRBSDSC:USU-LBR-SFLower&startDate=&endDate=&authToken=]( http://water.sdsc.edu/lbrsdsc/cuahsi_1_1.asmx/GetValuesObject?variable=LRBSDSC:USU4&location=LRBSDSC:USU-LBR-SFLower&startDate=&endDate=&authToken=)
* [ http://water.sdsc.edu/lbrsdsc/cuahsi_1_1.asmx/GetValuesObject?variable=LRBSDSC:USU4&location=LRBSDSC:USU-LBR-SFLower&startDate=&endDate=&authToken=]( http://water.sdsc.edu/lbrsdsc/cuahsi_1_1.asmx/GetValuesObject?variable=LRBSDSC:USU4&location=LRBSDSC:USU-LBR-SFLower&startDate=&endDate=&authToken=)

GetValuesForASite:
[ http://water.sdsc.edu/lbrsdsc/cuahsi_1_1.asmx/GetValuesForASiteObject?site=LRBSDSC:USU-LBR-SFLower&startDate=2008-01-01&endDate=2008-02-01&authToken=]( http://water.sdsc.edu/lbrsdsc/cuahsi_1_1.asmx/GetValuesForASiteObject?site=LRBSDSC:USU-LBR-SFLower&startDate=2008-01-01&endDate=2008-02-01&authToken=)
