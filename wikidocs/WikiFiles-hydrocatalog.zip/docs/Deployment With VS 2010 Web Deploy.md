(More work needed)

In VS 2010 you can build a web deploy package



NLDAS_MOS0125_H.deploy.cmd /T /M:River.sdsc.edu /U:Unsername "/P:Password"
